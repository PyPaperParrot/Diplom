# ClusterCardinality


This is the notebook to reproduce the results of the article:

[Gaussian Mixture Model clustering: how to select the number of components (clusters)](https://towardsdatascience.com/gaussian-mixture-model-clusterization-how-to-select-the-number-of-components-clusters-553bef45f6e4)
